#!/usr/bin/env python3
"""
专利申请PDF生成器
将markdown文件和SVG附图转换为CNIPA格式的PDF文件
"""

import os
import re
import io
import cairosvg
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak,
    Table, TableStyle, KeepTogether
)
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ============================================================
# 字体注册
# ============================================================
FONT_PATH = '/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf'
pdfmetrics.registerFont(TTFont('CJK', FONT_PATH))

BASE_DIR = '/home/admin/tools/cuijin/patent-application'
OUT_DIR = os.path.join(BASE_DIR, '07-filing-package')
os.makedirs(OUT_DIR, exist_ok=True)

# ============================================================
# 样式定义
# ============================================================
def make_styles():
    styles = getSampleStyleSheet()

    styles.add(ParagraphStyle(
        'CNTitle', fontName='CJK', fontSize=16, leading=24,
        alignment=TA_CENTER, spaceAfter=12, spaceBefore=6,
    ))
    styles.add(ParagraphStyle(
        'CNHeading1', fontName='CJK', fontSize=14, leading=20,
        alignment=TA_LEFT, spaceAfter=8, spaceBefore=16,
        textColor=colors.black,
    ))
    styles.add(ParagraphStyle(
        'CNHeading2', fontName='CJK', fontSize=12, leading=18,
        alignment=TA_LEFT, spaceAfter=6, spaceBefore=12,
    ))
    styles.add(ParagraphStyle(
        'CNBody', fontName='CJK', fontSize=10.5, leading=18,
        alignment=TA_JUSTIFY, spaceAfter=4, spaceBefore=2,
        firstLineIndent=21,  # 2字符缩进
    ))
    styles.add(ParagraphStyle(
        'CNBodyNoIndent', fontName='CJK', fontSize=10.5, leading=18,
        alignment=TA_JUSTIFY, spaceAfter=4, spaceBefore=2,
    ))
    styles.add(ParagraphStyle(
        'CNParagraphNum', fontName='CJK', fontSize=10.5, leading=18,
        alignment=TA_JUSTIFY, spaceAfter=4, spaceBefore=2,
        firstLineIndent=21,
    ))
    styles.add(ParagraphStyle(
        'CNClaim', fontName='CJK', fontSize=10.5, leading=18,
        alignment=TA_JUSTIFY, spaceAfter=6, spaceBefore=4,
        firstLineIndent=21,
    ))
    styles.add(ParagraphStyle(
        'CNSmall', fontName='CJK', fontSize=9, leading=14,
        alignment=TA_LEFT, spaceAfter=2,
    ))
    styles.add(ParagraphStyle(
        'CNTableCell', fontName='CJK', fontSize=9, leading=13,
        alignment=TA_CENTER,
    ))
    styles.add(ParagraphStyle(
        'CNTableCellLeft', fontName='CJK', fontSize=9, leading=13,
        alignment=TA_LEFT,
    ))
    styles.add(ParagraphStyle(
        'FigCaption', fontName='CJK', fontSize=10, leading=16,
        alignment=TA_CENTER, spaceAfter=8, spaceBefore=4,
    ))

    return styles

STYLES = make_styles()

# ============================================================
# SVG → ReportLab Image
# ============================================================
def svg_to_image(svg_path, max_width=160*mm, max_height=200*mm):
    """Convert SVG to a ReportLab Image via PNG intermediate."""
    png_data = cairosvg.svg2png(url=svg_path, output_width=1200)
    img_buf = io.BytesIO(png_data)
    img = Image(img_buf)
    # Scale to fit
    iw, ih = img.imageWidth, img.imageHeight
    if iw <= 0 or ih <= 0:
        return Image(img_buf, width=max_width, height=max_height)
    scale = min(max_width / iw, max_height / ih, 1.0)
    img._restrictSize(iw * scale, ih * scale)
    return img

# ============================================================
# 文本清理
# ============================================================
def clean_text(text):
    """Clean markdown text for ReportLab Paragraph."""
    text = text.replace('&', '&amp;')
    text = text.replace('<', '&lt;')
    text = text.replace('>', '&gt;')
    # Bold: **text**
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    # Remove remaining markdown artifacts
    text = text.replace('`', '')
    return text.strip()

# ============================================================
# 生成说明书PDF
# ============================================================
def build_specification_pdf():
    """生成说明书PDF（含附图嵌入）"""

    filepath = os.path.join(BASE_DIR, '03-specification', 'specification-full.md')
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Remove the trailing comment line
    content = content.replace('<!-- 权利要求书和摘要请见独立文件：02-claims/claims-final.md 和 05-front-matter/abstract.md -->', '')

    out_path = os.path.join(OUT_DIR, '说明书.pdf')
    doc = SimpleDocTemplate(
        out_path, pagesize=A4,
        leftMargin=25*mm, rightMargin=25*mm,
        topMargin=25*mm, bottomMargin=25*mm,
    )

    story = []

    # Title
    story.append(Paragraph('说  明  书', STYLES['CNTitle']))
    story.append(Spacer(1, 6*mm))

    # SVG file mapping for insertion
    fig_files = {
        '图1': 'fig1-overall-structure.svg',
        '图2': 'fig2-aeration-unit.svg',
        '图3': 'fig3-cutting-assembly.svg',
        '图4': 'fig4-tailgas-recycle.svg',
        '图5': 'fig5-control-logic.svg',
        '图6': 'fig6-dyeing-wastewater.svg',
        '图7': 'fig7-chemical-wastewater.svg',
    }
    fig_dir = os.path.join(BASE_DIR, '04-diagrams')

    # Track which figures have been inserted
    inserted_figures = set()

    # Figure insertion points (after which section heading)
    fig_insert_after_section = {
        '## 附图说明': ['图1', '图2', '图3', '图4', '图5', '图6', '图7'],
    }

    lines = content.split('\n')
    i = 0
    current_table_lines = []
    in_table = False

    while i < len(lines):
        line = lines[i]

        # Skip the top-level markdown title (already added as PDF title)
        if line.strip() == '# 发明专利说明书':
            i += 1
            continue

        # Section: ## 发明名称
        if line.strip() == '## 发明名称':
            story.append(Paragraph('发明名称', STYLES['CNHeading1']))
            i += 1
            # Next non-empty line is the title
            while i < len(lines) and not lines[i].strip():
                i += 1
            if i < len(lines):
                story.append(Paragraph(clean_text(lines[i].strip()), STYLES['CNBody']))
                i += 1
            continue

        # Main section headings: ## xxx
        if line.startswith('## '):
            heading_text = line[3:].strip()
            story.append(Paragraph(clean_text(heading_text), STYLES['CNHeading1']))

            # Insert figures after 附图说明 section
            if '附图说明' in heading_text:
                # The figure descriptions follow in the text; we insert figures at the end of this section
                pass

            i += 1
            continue

        # Sub-section headings: ### xxx
        if line.startswith('### '):
            heading_text = line[4:].strip()
            story.append(Paragraph(clean_text(heading_text), STYLES['CNHeading2']))
            i += 1
            continue

        # Sub-sub-section: #### xxx
        if line.startswith('#### '):
            heading_text = line[5:].strip()
            story.append(Paragraph(clean_text(heading_text), STYLES['CNHeading2']))
            i += 1
            continue

        # Table handling
        if '|' in line and line.strip().startswith('|'):
            if not in_table:
                in_table = True
                current_table_lines = []
            current_table_lines.append(line)
            i += 1
            continue
        elif in_table:
            # End of table
            in_table = False
            _add_table(story, current_table_lines)
            current_table_lines = []
            # Don't increment i, process current line
            continue

        # Paragraph text with [xxxx] numbering
        stripped = line.strip()
        if not stripped:
            i += 1
            continue

        # Handle paragraph number [0001] format
        para_match = re.match(r'\[(\d+)\]\s*(.*)', stripped)
        if para_match:
            num = para_match.group(1)
            text = para_match.group(2)
            # Collect continuation lines
            i += 1
            while i < len(lines) and lines[i].strip() and not lines[i].strip().startswith('[') \
                  and not lines[i].startswith('#') and not lines[i].strip().startswith('|'):
                text += ' ' + lines[i].strip()
                i += 1
            full_text = f'[{num}] {clean_text(text)}'
            story.append(Paragraph(full_text, STYLES['CNParagraphNum']))

            # Check if this paragraph references a figure - insert figure after relevant paragraphs
            for fig_key, fig_file in fig_files.items():
                if fig_key in stripped and fig_key not in inserted_figures:
                    # Insert figure right after relevant description paragraph
                    if ('如' + fig_key + '所示' in text or fig_key + '为本发明' in text):
                        fig_path = os.path.join(fig_dir, fig_file)
                        if os.path.exists(fig_path):
                            story.append(Spacer(1, 4*mm))
                            try:
                                img = svg_to_image(fig_path, max_width=155*mm, max_height=180*mm)
                                story.append(img)
                                story.append(Paragraph(fig_key, STYLES['FigCaption']))
                                inserted_figures.add(fig_key)
                            except Exception as e:
                                story.append(Paragraph(f'[{fig_key} 附图位置]', STYLES['FigCaption']))
                            story.append(Spacer(1, 4*mm))
            continue

        # Regular text
        text = stripped
        i += 1
        while i < len(lines) and lines[i].strip() and not lines[i].startswith('#') \
              and not lines[i].strip().startswith('[') and not lines[i].strip().startswith('|'):
            text += ' ' + lines[i].strip()
            i += 1
        story.append(Paragraph(clean_text(text), STYLES['CNBody']))

    # Flush any remaining table
    if in_table and current_table_lines:
        _add_table(story, current_table_lines)

    # Insert any figures not yet inserted at the end
    story.append(Spacer(1, 6*mm))
    for fig_key, fig_file in fig_files.items():
        if fig_key not in inserted_figures:
            fig_path = os.path.join(fig_dir, fig_file)
            if os.path.exists(fig_path):
                try:
                    img = svg_to_image(fig_path, max_width=155*mm, max_height=190*mm)
                    story.append(img)
                    story.append(Paragraph(fig_key, STYLES['FigCaption']))
                    story.append(Spacer(1, 6*mm))
                    inserted_figures.add(fig_key)
                except Exception as e:
                    story.append(Paragraph(f'[{fig_key} 附图位置]', STYLES['FigCaption']))

    doc.build(story)
    print(f'✅ 说明书PDF生成: {out_path}')
    return out_path


def _add_table(story, table_lines):
    """Parse markdown table and add to story."""
    rows = []
    for tl in table_lines:
        cells = [c.strip() for c in tl.strip().strip('|').split('|')]
        # Skip separator row (---)
        if all(set(c.replace('-', '').replace(':', '').strip()) == set() or c.strip().startswith('-') for c in cells):
            continue
        rows.append(cells)

    if not rows:
        return

    # Convert to Paragraph cells
    para_rows = []
    for ri, row in enumerate(rows):
        style = STYLES['CNTableCell'] if ri == 0 else STYLES['CNTableCellLeft']
        para_row = [Paragraph(clean_text(c), style) for c in row]
        para_rows.append(para_row)

    # Determine column widths
    ncols = max(len(r) for r in para_rows)
    available_width = 160 * mm
    col_width = available_width / ncols

    t = Table(para_rows, colWidths=[col_width]*ncols)
    t.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'CJK'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.Color(0.9, 0.9, 0.9)),
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
    ]))
    story.append(Spacer(1, 3*mm))
    story.append(t)
    story.append(Spacer(1, 3*mm))


# ============================================================
# 生成权利要求书PDF
# ============================================================
def build_claims_pdf():
    """生成权利要求书PDF"""
    filepath = os.path.join(BASE_DIR, '02-claims', 'claims-final.md')
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    out_path = os.path.join(OUT_DIR, '权利要求书.pdf')
    doc = SimpleDocTemplate(
        out_path, pagesize=A4,
        leftMargin=25*mm, rightMargin=25*mm,
        topMargin=25*mm, bottomMargin=25*mm,
    )

    story = []
    story.append(Paragraph('权 利 要 求 书', STYLES['CNTitle']))
    story.append(Spacer(1, 8*mm))

    lines = content.split('\n')
    i = 0
    while i < len(lines):
        line = lines[i].strip()

        # Skip markdown title
        if line == '# 权利要求书':
            i += 1
            continue

        if not line:
            i += 1
            continue

        # Claim number line: starts with number.
        claim_match = re.match(r'^(\d+)\.\s*(.*)', line)
        if claim_match:
            num = claim_match.group(1)
            text = claim_match.group(2)
            i += 1
            # Collect continuation
            while i < len(lines):
                next_line = lines[i].strip()
                if not next_line:
                    i += 1
                    continue
                if re.match(r'^\d+\.\s', next_line):
                    break
                text += '\n' + next_line
                i += 1

            # Format: replace newlines with <br/>
            text = clean_text(text)
            text = text.replace('\n', '<br/>')
            claim_text = f'<b>{num}.</b> {text}'
            story.append(Paragraph(claim_text, STYLES['CNClaim']))
            story.append(Spacer(1, 2*mm))
            continue

        i += 1

    doc.build(story)
    print(f'✅ 权利要求书PDF生成: {out_path}')
    return out_path


# ============================================================
# 生成摘要PDF
# ============================================================
def build_abstract_pdf():
    """生成说明书摘要PDF"""
    filepath = os.path.join(BASE_DIR, '05-front-matter', 'abstract.md')
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    out_path = os.path.join(OUT_DIR, '说明书摘要.pdf')
    doc = SimpleDocTemplate(
        out_path, pagesize=A4,
        leftMargin=25*mm, rightMargin=25*mm,
        topMargin=25*mm, bottomMargin=25*mm,
    )

    story = []
    story.append(Paragraph('说 明 书 摘 要', STYLES['CNTitle']))
    story.append(Spacer(1, 6*mm))

    # Title
    story.append(Paragraph('发明名称', STYLES['CNHeading2']))
    story.append(Paragraph('一种超微气泡-臭氧耦合深度水处理一体化设备', STYLES['CNBody']))
    story.append(Spacer(1, 4*mm))

    # Extract abstract text
    lines = content.split('\n')
    abstract_text = ''
    in_abstract = False
    for line in lines:
        if line.strip() == '## 摘要':
            in_abstract = True
            continue
        if line.strip() == '## 摘要附图':
            in_abstract = False
            continue
        if in_abstract and line.strip():
            abstract_text += line.strip() + ' '

    story.append(Paragraph('摘要', STYLES['CNHeading2']))
    story.append(Paragraph(clean_text(abstract_text.strip()), STYLES['CNBody']))
    story.append(Spacer(1, 6*mm))

    # Abstract figure
    story.append(Paragraph('摘要附图', STYLES['CNHeading2']))
    fig_path = os.path.join(BASE_DIR, '04-diagrams', 'fig1-overall-structure.svg')
    if os.path.exists(fig_path):
        try:
            img = svg_to_image(fig_path, max_width=155*mm, max_height=180*mm)
            story.append(img)
            story.append(Paragraph('图1', STYLES['FigCaption']))
        except Exception as e:
            story.append(Paragraph(f'[图1 摘要附图位置] 错误: {e}', STYLES['FigCaption']))

    doc.build(story)
    print(f'✅ 说明书摘要PDF生成: {out_path}')
    return out_path


# ============================================================
# 生成附图PDF（所有附图单独一个PDF）
# ============================================================
def build_figures_pdf():
    """生成说明书附图PDF"""
    out_path = os.path.join(OUT_DIR, '说明书附图.pdf')
    doc = SimpleDocTemplate(
        out_path, pagesize=A4,
        leftMargin=20*mm, rightMargin=20*mm,
        topMargin=20*mm, bottomMargin=20*mm,
    )

    fig_dir = os.path.join(BASE_DIR, '04-diagrams')
    fig_files = [
        ('图1', 'fig1-overall-structure.svg'),
        ('图2', 'fig2-aeration-unit.svg'),
        ('图3', 'fig3-cutting-assembly.svg'),
        ('图4', 'fig4-tailgas-recycle.svg'),
        ('图5', 'fig5-control-logic.svg'),
        ('图6', 'fig6-dyeing-wastewater.svg'),
        ('图7', 'fig7-chemical-wastewater.svg'),
    ]

    story = []
    story.append(Paragraph('说 明 书 附 图', STYLES['CNTitle']))
    story.append(Spacer(1, 10*mm))

    for idx, (caption, fname) in enumerate(fig_files):
        fig_path = os.path.join(fig_dir, fname)
        if os.path.exists(fig_path):
            try:
                img = svg_to_image(fig_path, max_width=170*mm, max_height=220*mm)
                story.append(img)
                story.append(Paragraph(caption, STYLES['FigCaption']))
            except Exception as e:
                story.append(Paragraph(f'[{caption} 转换失败: {e}]', STYLES['FigCaption']))
        else:
            story.append(Paragraph(f'[{caption} 文件未找到]', STYLES['FigCaption']))

        if idx < len(fig_files) - 1:
            story.append(PageBreak())

    doc.build(story)
    print(f'✅ 说明书附图PDF生成: {out_path}')
    return out_path


# ============================================================
# Main
# ============================================================
if __name__ == '__main__':
    print('='*60)
    print('专利申请PDF文件生成')
    print('发明名称：一种超微气泡-臭氧耦合深度水处理一体化设备')
    print('发明人：张兆勇')
    print('申请人：北京睿美达环保新材料科技有限公司')
    print('='*60)
    print()

    build_specification_pdf()
    build_claims_pdf()
    build_abstract_pdf()
    build_figures_pdf()

    print()
    print('='*60)
    print('全部PDF文件已生成至:')
    print(f'  {OUT_DIR}/')
    for f in sorted(os.listdir(OUT_DIR)):
        if f.endswith('.pdf'):
            fpath = os.path.join(OUT_DIR, f)
            size_kb = os.path.getsize(fpath) / 1024
            print(f'  ├── {f}  ({size_kb:.0f} KB)')
    print('='*60)
