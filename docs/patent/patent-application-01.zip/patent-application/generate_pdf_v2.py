#!/usr/bin/env python3
"""
专利申请PDF生成器 v2 — 基于 WeasyPrint (HTML→PDF)
- 使用 markdown 库将 .md 转为 HTML
- 使用 cairosvg 将 SVG 内联转为 base64 PNG 嵌入 HTML
- 使用 WeasyPrint 生成高质量 A4 PDF
- 附图嵌入说明书中"如图X所示"首次出现的位置
"""

import os, re, base64, io, markdown, cairosvg, weasyprint

BASE = '/home/admin/tools/cuijin/patent-application'
OUT  = os.path.join(BASE, '07-filing-package')
os.makedirs(OUT, exist_ok=True)

DIAGRAM_DIR = os.path.join(BASE, '04-diagrams')

# ============================================================
# CSS — 模拟 CNIPA 专利文件排版
# ============================================================
CSS_PATENT = """
@page {
    size: A4;
    margin: 25mm 25mm 25mm 25mm;
    @bottom-center {
        content: counter(page);
        font-family: "Noto Serif CJK SC", serif;
        font-size: 9pt;
    }
}
body {
    font-family: "Noto Serif CJK SC", "Noto Sans CJK SC", "Droid Sans Fallback", serif;
    font-size: 10.5pt;
    line-height: 1.8;
    color: #000;
    text-align: justify;
}
h1 {
    font-size: 16pt;
    text-align: center;
    margin-top: 0;
    margin-bottom: 12pt;
    font-weight: bold;
    letter-spacing: 6pt;
}
h2 {
    font-size: 14pt;
    font-weight: bold;
    margin-top: 18pt;
    margin-bottom: 8pt;
    border-bottom: none;
}
h3 {
    font-size: 12pt;
    font-weight: bold;
    margin-top: 14pt;
    margin-bottom: 6pt;
}
h4 {
    font-size: 11pt;
    font-weight: bold;
    margin-top: 10pt;
    margin-bottom: 4pt;
}
p {
    text-indent: 2em;
    margin-top: 3pt;
    margin-bottom: 3pt;
}
p.no-indent {
    text-indent: 0;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin: 8pt 0;
    font-size: 9pt;
}
th, td {
    border: 0.5pt solid #000;
    padding: 4pt 6pt;
    text-align: center;
    vertical-align: middle;
}
th {
    background-color: #f0f0f0;
    font-weight: bold;
}
td {
    text-align: left;
}
img.patent-figure {
    display: block;
    margin: 10pt auto;
    max-width: 100%;
    max-height: 240mm;
}
p.figure-caption {
    text-align: center;
    text-indent: 0;
    font-size: 10pt;
    margin-top: 4pt;
    margin-bottom: 10pt;
}
.page-break {
    page-break-before: always;
}
/* 权利要求书专用 */
.claim {
    text-indent: 2em;
    margin-bottom: 6pt;
}
.claim-number {
    font-weight: bold;
}
"""

# ============================================================
# SVG → 内联 base64 PNG <img> 标签
# ============================================================
def svg_to_img_tag(svg_path, caption=None, css_class='patent-figure'):
    """将SVG转换为内嵌base64 PNG的<img>标签"""
    try:
        png_data = cairosvg.svg2png(url=svg_path, output_width=1600)
        b64 = base64.b64encode(png_data).decode('ascii')
        html = f'<img class="{css_class}" src="data:image/png;base64,{b64}" />\n'
        if caption:
            html += f'<p class="figure-caption">{caption}</p>\n'
        return html
    except Exception as e:
        return f'<p class="figure-caption">[{caption or "附图"} 转换错误: {e}]</p>\n'

# ============================================================
# Markdown → HTML（保留原始段落编号格式）
# ============================================================
def md_to_html_body(md_text):
    """将markdown转为HTML body内容，使用python-markdown库"""
    # 先用markdown库转换
    html = markdown.markdown(md_text, extensions=['tables', 'fenced_code'])
    return html

# ============================================================
# 1. 生成说明书PDF（含附图嵌入）
# ============================================================
def build_specification():
    print('📄 生成说明书PDF...')

    with open(os.path.join(BASE, '03-specification', 'specification-full.md'), 'r') as f:
        md_text = f.read()

    # 去除末尾注释
    md_text = md_text.replace('<!-- 权利要求书和摘要请见独立文件：02-claims/claims-final.md 和 05-front-matter/abstract.md -->', '')

    # 替换顶层标题
    md_text = md_text.replace('# 发明专利说明书', '# 说　明　书', 1)

    # 将md转为HTML
    body_html = md_to_html_body(md_text)

    # ---- 嵌入附图到正确位置 ----
    # 策略：在"附图说明"章节内，每个图描述段落后插入对应图片
    # 同时在"具体实施方式"中"如图X所示"的首次引用段落后也插入

    fig_map = {
        '图1': ('fig1-overall-structure.svg', '图1'),
        '图2': ('fig2-aeration-unit.svg', '图2'),
        '图3': ('fig3-cutting-assembly.svg', '图3'),
        '图4': ('fig4-tailgas-recycle.svg', '图4'),
        '图5': ('fig5-control-logic.svg', '图5'),
        '图6': ('fig6-dyeing-wastewater.svg', '图6'),
        '图7': ('fig7-chemical-wastewater.svg', '图7'),
    }

    # 在附图说明章节的每个图描述后插入图片
    for fig_key, (fig_file, caption) in fig_map.items():
        svg_path = os.path.join(DIAGRAM_DIR, fig_file)
        if not os.path.exists(svg_path):
            continue
        img_tag = svg_to_img_tag(svg_path, caption)

        # 寻找 "[00XX] 图N为本发明..." 的段落，在其后插入图片
        # HTML中这些是<p>标签
        pattern = re.compile(
            rf'(<p>\[00\d+\]\s*{re.escape(fig_key)}为本发明.*?</p>)',
            re.DOTALL
        )
        match = pattern.search(body_html)
        if match:
            body_html = body_html[:match.end()] + '\n' + img_tag + body_html[match.end():]

    # 组装完整HTML
    full_html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><style>{CSS_PATENT}</style></head>
<body>
{body_html}
</body>
</html>"""

    out_path = os.path.join(OUT, '说明书.pdf')
    weasyprint.HTML(string=full_html).write_pdf(out_path)
    size_kb = os.path.getsize(out_path) / 1024
    print(f'  ✅ 说明书.pdf ({size_kb:.0f} KB)')

# ============================================================
# 2. 生成权利要求书PDF
# ============================================================
def build_claims():
    print('📄 生成权利要求书PDF...')

    with open(os.path.join(BASE, '02-claims', 'claims-final.md'), 'r') as f:
        md_text = f.read()

    body_html = md_to_html_body(md_text)

    # 替换标题格式
    body_html = body_html.replace('<h1>权利要求书</h1>', '<h1>权 利 要 求 书</h1>')

    full_html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><style>{CSS_PATENT}</style></head>
<body>
{body_html}
</body>
</html>"""

    out_path = os.path.join(OUT, '权利要求书.pdf')
    weasyprint.HTML(string=full_html).write_pdf(out_path)
    size_kb = os.path.getsize(out_path) / 1024
    print(f'  ✅ 权利要求书.pdf ({size_kb:.0f} KB)')

# ============================================================
# 3. 生成说明书摘要PDF（含摘要附图）
# ============================================================
def build_abstract():
    print('📄 生成说明书摘要PDF...')

    with open(os.path.join(BASE, '05-front-matter', 'abstract.md'), 'r') as f:
        md_text = f.read()

    # 替换标题
    md_text = md_text.replace('# 发明摘要', '# 说 明 书 摘 要')

    body_html = md_to_html_body(md_text)

    # 在"摘要附图"部分插入图1
    fig1_path = os.path.join(DIAGRAM_DIR, 'fig1-overall-structure.svg')
    if os.path.exists(fig1_path):
        img_tag = svg_to_img_tag(fig1_path, '图1')
        # 替换 "图1" 文字为实际图片
        body_html = body_html.replace('<p>图1</p>', img_tag)

    full_html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><style>{CSS_PATENT}</style></head>
<body>
{body_html}
</body>
</html>"""

    out_path = os.path.join(OUT, '说明书摘要.pdf')
    weasyprint.HTML(string=full_html).write_pdf(out_path)
    size_kb = os.path.getsize(out_path) / 1024
    print(f'  ✅ 说明书摘要.pdf ({size_kb:.0f} KB)')

# ============================================================
# 4. 生成说明书附图PDF（每张图单独一页）
# ============================================================
def build_figures():
    print('📄 生成说明书附图PDF...')

    figs = [
        ('fig1-overall-structure.svg', '图1'),
        ('fig2-aeration-unit.svg', '图2'),
        ('fig3-cutting-assembly.svg', '图3'),
        ('fig4-tailgas-recycle.svg', '图4'),
        ('fig5-control-logic.svg', '图5'),
        ('fig6-dyeing-wastewater.svg', '图6'),
        ('fig7-chemical-wastewater.svg', '图7'),
    ]

    body_parts = ['<h1>说 明 书 附 图</h1>']
    for idx, (fname, caption) in enumerate(figs):
        svg_path = os.path.join(DIAGRAM_DIR, fname)
        if idx > 0:
            body_parts.append('<div class="page-break"></div>')
        if os.path.exists(svg_path):
            body_parts.append(svg_to_img_tag(svg_path, caption))
        else:
            body_parts.append(f'<p class="figure-caption">[{caption} 文件缺失]</p>')

    css_figures = CSS_PATENT + """
    img.patent-figure {
        max-height: 230mm;
    }
    """

    full_html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><style>{css_figures}</style></head>
<body>
{''.join(body_parts)}
</body>
</html>"""

    out_path = os.path.join(OUT, '说明书附图.pdf')
    weasyprint.HTML(string=full_html).write_pdf(out_path)
    size_kb = os.path.getsize(out_path) / 1024
    print(f'  ✅ 说明书附图.pdf ({size_kb:.0f} KB)')

# ============================================================
# Main
# ============================================================
if __name__ == '__main__':
    print('='*60)
    print('  专利申请PDF生成 v2 (WeasyPrint)')
    print('  发明：一种超微气泡-臭氧耦合深度水处理一体化设备')
    print('  发明人：张兆勇')
    print('  申请人：北京睿美达环保新材料科技有限公司')
    print('='*60)
    print()

    build_specification()
    build_claims()
    build_abstract()
    build_figures()

    print()
    print('='*60)
    print('  全部PDF生成完毕：')
    for f in sorted(os.listdir(OUT)):
        if f.endswith('.pdf'):
            fpath = os.path.join(OUT, f)
            size_kb = os.path.getsize(fpath) / 1024
            print(f'    {f:20s}  {size_kb:>7.0f} KB')
    print(f'  目录: {OUT}/')
    print('='*60)
